// ============================================
// التفاعلات والوظائف الديناميكية
// ============================================

// تحميل البيانات من ملف JSON (إذا كان موجوداً)
let domainsData = {
    leadership: {
        title: "القيادة المدرسية",
        description: "رؤية وإدارة استراتيجية لتحقيق التميز التعليمي",
        icon: "🏫",
        documents: [
            "محاضر الاجتماعات",
            "تقارير مستويات الإنجاز والجودة",
            "برامج النشاط اللاصفي",
            "خطة المدرسة السنوية",
            "أنظمة وإجراءات متابعة ومراقبة تنفيذ الخطط",
            "تقارير متابعة الأداء",
            "القرارات والتعاميم الداخلية",
            "ملاحظات المسؤولين في سجل الزيارات",
            "تقارير برامج التوجيه الأخلاقي",
            "بطاقة حضور الدروس",
            "سجل متابعة أداء المعلم",
            "التعاميم الداخلية لتدريب المعلمين",
            "برامج رفع الوعي",
            "تقارير البرامج",
            "سجل الحالات الطارئة",
            "محاضر التحقيق ومجالس التأديب",
            "خطة الإرشاد",
            "تقارير النشاط والمسابقات",
            "خطط التطوير",
            "قرارات تشكيل واعتماد المجالس",
            "خطة تبادل الزيارات",
            "تقارير عن التأكد من فهم الأنظمة واللوائح والسياسات",
            "البرامج والتقنيات المستخدمة",
            "خطابات الشكر",
            "سجلات المرشد الطلابي",
            "مخاطبات أولياء الأمور",
            "وسائل التواصل المستخدمة",
            "مخاطبات مؤسسات المجتمع",
            "محاضر الاجتماعات مع مؤسسات المجتمع",
            "حلقات النقاش",
            "سجل التقويم",
            "خطة التطوير",
            "سجل توزيع المهام",
            "البرامج والتقنيات المستخدمة",
            "الموقع الإلكتروني"
        ]
    },
    teaching: {
        title: "التعليم والتعلم",
        description: "ممارسات تعليمية مبتكرة وتقويم شامل للأداء",
        icon: "📘",
        documents: [
            "ملفات إنجاز الطلاب (البورتفوليو)",
            "أنشطة التعليم والتعلم",
            "عينة الأنشطة الصفية",
            "سجل متابعة أداء المعلم",
            "عينة من وثائق بحث الدرس",
            "دفاتر إعداد الدروس",
            "عينة من نماذج تقويم أداء الطلاب",
            "تقارير تحليل نتائج التقويم والاختبارات التحصيلية",
            "تقارير نتائج تحليل الأدوات",
            "شهادات ووثائق المشاركة في مجتمعات التعلم المهني",
            "تقارير التقويم الذاتي وأنشطة التأمل الذاتي",
            "القرارات المهنية وخطط التحسين التي تم اتخاذها في ضوء ممارسات التأمل المهني",
            "وثائق البحوث الإجرائية"
        ]
    },
    outcomes: {
        title: "نتائج التعلم",
        description: "إنجازات الطلاب ومخرجات التعلم المقاسة",
        icon: "📊",
        documents: [
            "تقارير نتائج تحصيل الطلاب في المواد الأساسية ونسبة الذين حققوا درجة النجاح",
            "تقارير نتائج تحصيل الطلاب في المواد الفرعية ونسبة الذين حققوا درجة النجاح",
            "تقارير نتائج الاختبارات الدولية ومقارنتها مع درجات الطلاب",
            "تقارير المشاركة في المسابقات المحلية والخارجية",
            "سجلات الحضور",
            "سجلات المرشد الطلابي",
            "سجل الحالات الطارئة"
        ]
    }
};

// ============================================
// وظائف عامة
// ============================================

// تهيئة الصفحة عند التحميل
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    loadDomainCards();
    addSmoothScroll();
});

// إضافة مستمعي الأحداث
function initializeEventListeners() {
    // زر "ابدأ الجولة"
    const startTourBtn = document.querySelector('[data-action="start-tour"]');
    if (startTourBtn) {
        startTourBtn.addEventListener('click', function() {
            const firstDomain = document.querySelector('.domain-card');
            if (firstDomain) {
                firstDomain.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    }

    // أزرار "عرض الشواهد"
    document.querySelectorAll('.btn-view').forEach(btn => {
        btn.addEventListener('click', function() {
            const domainTitle = this.closest('.domain-card').querySelector('h3').textContent;
            showNotification(`سيتم قريباً عرض الشواهد الخاصة بـ: ${domainTitle}`);
        });
    });
}

// تحميل بطاقات المجالات
function loadDomainCards() {
    const container = document.querySelector('.domains-grid');
    if (!container) return;

    Object.values(domainsData).forEach(domain => {
        const card = createDomainCard(domain);
        container.appendChild(card);
    });
}

// إنشاء بطاقة مجال
function createDomainCard(domain) {
    const card = document.createElement('div');
    card.className = 'domain-card';
    card.innerHTML = `
        <div class="domain-card-header">
            <div style="font-size: 3rem; margin-bottom: 0.5rem;">${domain.icon}</div>
            <h3>${domain.title}</h3>
        </div>
        <div class="domain-card-body">
            <p style="color: var(--text-light); margin-bottom: 1rem;">${domain.description}</p>
            <h4 style="color: var(--primary-color); margin-bottom: 1rem;">الوثائق المطلوبة:</h4>
            <ul class="documents-list">
                ${domain.documents.map(doc => `<li><span>${doc}</span></li>`).join('')}
            </ul>
            <button class="btn-view">عرض الشواهد</button>
        </div>
    `;
    return card;
}

// إضافة التمرير السلس
function addSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

// إظهار إشعار
function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background-color: var(--primary-color);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: var(--shadow-lg);
        z-index: 1000;
        animation: slideInDown 0.3s ease-out;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideInUp 0.3s ease-out reverse';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// ============================================
// وظائف إضافية
// ============================================

// البحث عن الوثائق
function searchDocuments(query) {
    const results = [];
    Object.values(domainsData).forEach(domain => {
        const matchingDocs = domain.documents.filter(doc => 
            doc.includes(query)
        );
        if (matchingDocs.length > 0) {
            results.push({
                domain: domain.title,
                documents: matchingDocs
            });
        }
    });
    return results;
}

// عد الوثائق الكلية
function getTotalDocumentsCount() {
    let total = 0;
    Object.values(domainsData).forEach(domain => {
        total += domain.documents.length;
    });
    return total;
}

// عرض إحصائيات
function displayStatistics() {
    console.log('إحصائيات المعرض الرقمي:');
    console.log('عدد المجالات:', Object.keys(domainsData).length);
    console.log('إجمالي الوثائق:', getTotalDocumentsCount());
    Object.values(domainsData).forEach(domain => {
        console.log(`- ${domain.title}: ${domain.documents.length} وثيقة`);
    });
}

// استدعاء الإحصائيات عند التحميل
displayStatistics();
